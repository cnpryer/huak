
import example_package.example_module.Example;



example = Example()

print(example)

print("wow, what an example!")

